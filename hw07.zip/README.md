Juan and Sean are collaborating on this assignment.
